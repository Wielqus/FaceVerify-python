from faceverify import functions

def test_test():
    assert functions.test() == 1