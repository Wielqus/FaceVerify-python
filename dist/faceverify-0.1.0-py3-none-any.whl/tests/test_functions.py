from faceverify import functions

def test_sum():
    assert functions.sum(2, 2) == 4