def test():
    return 1